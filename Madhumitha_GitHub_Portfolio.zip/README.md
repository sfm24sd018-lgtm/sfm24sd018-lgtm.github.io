# Madhumitha D — Developer Portfolio

A responsive personal portfolio built with HTML and CSS.

## Included sections
- About
- Skills and technologies
- Projects: DreamFashion, FreshMart, Excel Invoice & Billing System
- Internship and education details
- Contact

## Preview locally
Open `index.html` in a web browser.

## Publish with GitHub Pages
1. Create a **public** GitHub repository named `YOURUSERNAME.github.io` (replace with your GitHub username).
2. Upload `index.html`, `style.css`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait a few minutes and open `https://YOURUSERNAME.github.io/`.

## Before publishing
- Replace the LinkedIn placeholder with your exact LinkedIn profile URL.
- Replace the GitHub placeholder with your GitHub profile URL.
- Add real GitHub repository/live-demo links for each project when ready.
- If you want a resume download button, add your resume PDF to this repository and link it from the HTML.
- Review contact details before making the repository public.

This version uses plain HTML/CSS so it is easy to publish with GitHub Pages. It does not claim that project demos are live.
